#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 01:34:48 2024

@author: ankurtandan_snhu
"""

from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Connection Variables to connect to database/collection on particular port and host.
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30471
        DB = 'AAC'
        COL = 'animals'
        
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Creating."""
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred during insert: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, search_query):
        """Reading."""
        if search_query is not None:
            try:
                results = list(self.collection.find(search_query))
                return results
            except Exception as e:
                print(f"An error occurred during read: {e}")
                return []
        else:
            raise ValueError("Search query is None, please provide a valid search query.")

    def update(self, search_query, update_values):
        """Updating."""  
        if search_query is not None and update_values is not None:
            try:
                result = self.collection.update_many(search_query, {'$set': update_values})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred during update: {e}")
                return 0
        else:
            raise ValueError("Search query or update values are None.")

    def delete(self, search_query):
        """Deleting."""
        if search_query is not None:
            try:
                result = self.collection.delete_many(search_query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred during delete: {e}")
                return 0
        else:
            raise ValueError("Search query is None.")
